export default function Home() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>🚀 My Next.js App (v15.5.2)</h1>
      <p>Deployed on Vercel successfully!</p>
    </div>
  );
}
